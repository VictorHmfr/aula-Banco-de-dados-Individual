create database funcdepart;

create table funcionario(
func_cd_id serial primary key not null,
func_tx_nome varchar(100) not null,
func_dt_datanascimento date not null,
func_tx_genero varchar(20) not null,
func_tx_cargo varchar(20) not null,
func_tx_especializacao varchar(20) not null,
func_tx_cpf varchar(20) not null,
func_tx_email varchar(50) not null,
func_fk_end int4 not null,
func_fk_dep int4 not null,
foreign key(func_fk_end) references endereco(end_cd_id),
foreign key(func_fk_dep) references departamento(dep_cd_id)
);

create table endereco(
end_cd_id serial primary key not null,
end_tx_cep varchar(10) not null,
end_tx_logradouro varchar(100) not null,
end_tx_cidade varchar(20) not null,
end_tx_uf varchar(2) not null,
end_int_num int4 not null,
end_tx_complemento varchar(20),
end_tx_referencia varchar(100)
);

create table departamento(
dep_cd_id serial primary key not null,
dep_tx_nome varchar(50) not null,
dep_tx_areaesp varchar(50) not null,
dep_tx_tipodep varchar(50) not null,
dep_tx_status varchar (10) not null,
dep_fk_end int4 not null,
foreign key(dep_fk_end) references endereco(end_cd_id)
);

create table projeto(
proj_cd_id serial primary key not null,
proj_tx_nome varchar(50) not null,
proj_tx_descricao varchar(100) not null,
proj_dt_datainicio date not null,
proj_dt_datatermino date not null,
proj_int_orcamento int8 not null
);

create table trabalha_em(
trabem_cd_id serial primary key not null,
trabem_dt_datainicio date not null,
trabem_dt_datatermino date not null,
trabem_int_horastrabalhadas int2 not null,
trabem_tx_funcao varchar(30) not null,
trabem_fk_func int4 not null,
trabem_fk_proj int4 not null,
foreign key(trabem_fk_func) references funcionario(func_cd_id),
foreign key(trabem_fk_proj) references projeto(proj_cd_id)
);

insert into funcionario(func_tx_nome, func_dt_datanascimento, func_tx_genero, func_tx_cargo, func_tx_especializacao, func_tx_cpf, func_tx_email, func_fk_end, func_fk_dep)
values ('Jorge', '2000/05/20', 'Masculino', 'Auxiliar', 'Produção', '031.346.943-00', 'jorgingrande@gmail.com', 1, 1),
	('Jessica', '1998/05/20', 'Feminino', 'Analista', 'Dados', '346.924.423-86', 'jessicatavares234@gmail.com', 2, 2),
	('Mandy', '2001/05/20', 'Feminino', 'Gestão de vendas', 'Vendas', '072.496.239-59', 'mmndysouza8843@gmail.com', 3, 3),
	('Will', '1987/05/20', 'Masculino', 'Gerente', 'Administração', '782.956.130.85', 'willrobertsoares@gmail.com', 4, 4),
	('Benjamin', '1995/05/20', 'Masculino', 'Auxiliar', 'Produção', '931.562.729-45', 'benjaminbomdepapo8842@gmail.com', 5, 5);
	


insert into endereco(end_tx_cep, end_tx_logradouro, end_tx_cidade, end_tx_uf, end_int_num, end_tx_complemento, end_tx_referencia)
values ('04456-294', 'Rua Augusta', 'São Paulo', 'SP', '532', '', ''),
	('43752-213', 'Rua Barão de Jaguara', 'Campinas', 'SP', '368', '', 'Ao lado da loja de ferragens'),
	('85479-324', 'Avenida Ana Costa', 'Santos', 'SP', '1632', '', ''),
	('07698-896', 'Rua da Conceição', 'Niterói', 'RJ', '945', '', ''),
	('18436-638', 'Avenida Brigadeiro Lima e Silva', 'Duque de Caxias', 'RJ', '142', '', ''),
	('24255-243', 'Avenida Barros', 'Santana de Parnaíba', 'SP', '213', '', '');

insert into departamento(dep_tx_nome, dep_tx_areaesp, dep_tx_tipodep, dep_tx_status, dep_fk_end)
values ('Departamento de Produção', 'Produção', 'Planejamento, gestão e controle de estoque', 'Ativo', 1),
	('Departamento de Pesquisa', 'Pesquisa e Análise de dados', 'Análise e pesquisa de mercado', 'Ativo', 2),
	('Departamento de Vendas', 'Vendas e Gestão de pessoas', 'Vendas de estoque', 'Ativo', 3),
	('Departamento de Gerencia', 'Admnistração', 'Planejamento e gerecenciamento da empresa', 'Ativo', 4),
	('Departamento de Produção', 'Produção', 'Planejamento, gestão e controle de estoque', 'Ativo', 5);

insert into projeto(proj_tx_nome, proj_tx_descricao, proj_dt_datainicio, proj_dt_datatermino, proj_int_orcamento)
values ('Criação X920', 'Projeto na criação de um produto novo', '2012/07/30', '2024/03/23', 3500000 ),
	('Análise de pesquisa de mercado', 'Análise das necessidades do mercado', '2018/04/11', '2022/08/09', 1200000 ),
	('Análise de pesquisa de mercado', 'Análise das necessidades do mercado', '2018/04/11', '2022/08/09', 1200000 ),
	('Gerenciamento de Empresas de diferentes destinos', 'Projeto de junção de diferentes empresas', '2001/09/17', '2021/12/01', 6100000 ),
	('Criação X920', 'Projeto na criação de um produto novo', '2012/07/30', '2024/03/23', 3500000 );

insert into trabalha_em(trabem_dt_datainicio, trabem_dt_datatermino, trabem_int_horastrabalhadas, trabem_tx_funcao, trabem_fk_func, trabem_fk_proj)
values('2012/07/30', '2024/03/23', 520, 'Auxiliar', 1, 1),
	('2018/04/11', '2022/08/09', 270, 'Chefe do projeto', 2, 2),
	('2018/05/16', '2022/08/09', 250, 'Gerente', 3, 3),
	('2001/09/17', '2021/12/01', 1200, 'Chefe de desenvolvimento', 4, 4),
	('2012/07/30', '2024/03/23', 270, 'Auxiliar', 5, 5);


