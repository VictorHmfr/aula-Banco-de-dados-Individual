select f.func_tx_nome, e.end_tx_logradouro, e.end_tx_cep, e.end_int_num
from endereco e
join funcionario f on e.end_cd_id = f.func_fk_end
where func_cd_id = 1;

select f.func_tx_nome, te.trabem_int_horastrabalhadas, te.trabem_tx_funcao
from funcionario f 
join trabalha_em te on f.func_cd_id = te.trabem_fk_func
where func_cd_id = 3;

select f.func_tx_nome, d.dep_tx_nome, d.dep_tx_areaesp, d.dep_tx_tipodep, d.dep_tx_status
from departamento d
join funcionario f on dep_cd_id = f.func_fk_dep
where func_cd_id = 5 ;

select count(*) from funcionario f where  func_tx_especializacao = 'Produção' ;

