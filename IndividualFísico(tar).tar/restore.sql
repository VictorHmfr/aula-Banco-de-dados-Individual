--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE funcdepart;
--
-- Name: funcdepart; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE funcdepart WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE funcdepart OWNER TO postgres;

\connect funcdepart

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: departamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departamento (
    dep_cd_id integer NOT NULL,
    dep_tx_nome character varying(50) NOT NULL,
    dep_tx_areaesp character varying(50) NOT NULL,
    dep_tx_tipodep character varying(50) NOT NULL,
    dep_tx_status character varying(10) NOT NULL,
    dep_fk_end integer NOT NULL
);


ALTER TABLE public.departamento OWNER TO postgres;

--
-- Name: departamento_dep_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.departamento_dep_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.departamento_dep_cd_id_seq OWNER TO postgres;

--
-- Name: departamento_dep_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.departamento_dep_cd_id_seq OWNED BY public.departamento.dep_cd_id;


--
-- Name: endereco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endereco (
    end_cd_id integer NOT NULL,
    end_tx_cep character varying(10) NOT NULL,
    end_tx_logradouro character varying(100) NOT NULL,
    end_tx_cidade character varying(20) NOT NULL,
    end_tx_uf character varying(2) NOT NULL,
    end_int_num integer NOT NULL,
    end_tx_complemento character varying(20),
    end_tx_referencia character varying(100)
);


ALTER TABLE public.endereco OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.endereco_end_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.endereco_end_cd_id_seq OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.endereco_end_cd_id_seq OWNED BY public.endereco.end_cd_id;


--
-- Name: funcionario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.funcionario (
    func_cd_id integer NOT NULL,
    func_tx_nome character varying(100) NOT NULL,
    func_dt_datanascimento date NOT NULL,
    func_tx_genero character varying(20) NOT NULL,
    func_tx_cargo character varying(20) NOT NULL,
    func_tx_especializacao character varying(20) NOT NULL,
    func_tx_cpf character varying(20) NOT NULL,
    func_tx_email character varying(50) NOT NULL,
    func_fk_end integer NOT NULL,
    func_fk_dep integer NOT NULL
);


ALTER TABLE public.funcionario OWNER TO postgres;

--
-- Name: funcionario_func_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.funcionario_func_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.funcionario_func_cd_id_seq OWNER TO postgres;

--
-- Name: funcionario_func_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.funcionario_func_cd_id_seq OWNED BY public.funcionario.func_cd_id;


--
-- Name: projeto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projeto (
    proj_cd_id integer NOT NULL,
    proj_tx_nome character varying(50) NOT NULL,
    proj_tx_descricao character varying(100) NOT NULL,
    proj_dt_datainicio date NOT NULL,
    proj_dt_datatermino date NOT NULL,
    proj_int_orcamento bigint NOT NULL
);


ALTER TABLE public.projeto OWNER TO postgres;

--
-- Name: projeto_proj_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.projeto_proj_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.projeto_proj_cd_id_seq OWNER TO postgres;

--
-- Name: projeto_proj_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.projeto_proj_cd_id_seq OWNED BY public.projeto.proj_cd_id;


--
-- Name: trabalha_em; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trabalha_em (
    trabem_cd_id integer NOT NULL,
    trabem_dt_datainicio date NOT NULL,
    trabem_dt_datatermino date NOT NULL,
    trabem_int_horastrabalhadas smallint NOT NULL,
    trabem_tx_funcao character varying(30) NOT NULL,
    trabem_fk_func integer NOT NULL,
    trabem_fk_proj integer NOT NULL
);


ALTER TABLE public.trabalha_em OWNER TO postgres;

--
-- Name: trabalha_em_trabem_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trabalha_em_trabem_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trabalha_em_trabem_cd_id_seq OWNER TO postgres;

--
-- Name: trabalha_em_trabem_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trabalha_em_trabem_cd_id_seq OWNED BY public.trabalha_em.trabem_cd_id;


--
-- Name: departamento dep_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamento ALTER COLUMN dep_cd_id SET DEFAULT nextval('public.departamento_dep_cd_id_seq'::regclass);


--
-- Name: endereco end_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco ALTER COLUMN end_cd_id SET DEFAULT nextval('public.endereco_end_cd_id_seq'::regclass);


--
-- Name: funcionario func_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario ALTER COLUMN func_cd_id SET DEFAULT nextval('public.funcionario_func_cd_id_seq'::regclass);


--
-- Name: projeto proj_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projeto ALTER COLUMN proj_cd_id SET DEFAULT nextval('public.projeto_proj_cd_id_seq'::regclass);


--
-- Name: trabalha_em trabem_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trabalha_em ALTER COLUMN trabem_cd_id SET DEFAULT nextval('public.trabalha_em_trabem_cd_id_seq'::regclass);


--
-- Data for Name: departamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departamento (dep_cd_id, dep_tx_nome, dep_tx_areaesp, dep_tx_tipodep, dep_tx_status, dep_fk_end) FROM stdin;
\.
COPY public.departamento (dep_cd_id, dep_tx_nome, dep_tx_areaesp, dep_tx_tipodep, dep_tx_status, dep_fk_end) FROM '$$PATH$$/4820.dat';

--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.endereco (end_cd_id, end_tx_cep, end_tx_logradouro, end_tx_cidade, end_tx_uf, end_int_num, end_tx_complemento, end_tx_referencia) FROM stdin;
\.
COPY public.endereco (end_cd_id, end_tx_cep, end_tx_logradouro, end_tx_cidade, end_tx_uf, end_int_num, end_tx_complemento, end_tx_referencia) FROM '$$PATH$$/4818.dat';

--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.funcionario (func_cd_id, func_tx_nome, func_dt_datanascimento, func_tx_genero, func_tx_cargo, func_tx_especializacao, func_tx_cpf, func_tx_email, func_fk_end, func_fk_dep) FROM stdin;
\.
COPY public.funcionario (func_cd_id, func_tx_nome, func_dt_datanascimento, func_tx_genero, func_tx_cargo, func_tx_especializacao, func_tx_cpf, func_tx_email, func_fk_end, func_fk_dep) FROM '$$PATH$$/4822.dat';

--
-- Data for Name: projeto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projeto (proj_cd_id, proj_tx_nome, proj_tx_descricao, proj_dt_datainicio, proj_dt_datatermino, proj_int_orcamento) FROM stdin;
\.
COPY public.projeto (proj_cd_id, proj_tx_nome, proj_tx_descricao, proj_dt_datainicio, proj_dt_datatermino, proj_int_orcamento) FROM '$$PATH$$/4824.dat';

--
-- Data for Name: trabalha_em; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trabalha_em (trabem_cd_id, trabem_dt_datainicio, trabem_dt_datatermino, trabem_int_horastrabalhadas, trabem_tx_funcao, trabem_fk_func, trabem_fk_proj) FROM stdin;
\.
COPY public.trabalha_em (trabem_cd_id, trabem_dt_datainicio, trabem_dt_datatermino, trabem_int_horastrabalhadas, trabem_tx_funcao, trabem_fk_func, trabem_fk_proj) FROM '$$PATH$$/4826.dat';

--
-- Name: departamento_dep_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.departamento_dep_cd_id_seq', 5, true);


--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.endereco_end_cd_id_seq', 6, true);


--
-- Name: funcionario_func_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.funcionario_func_cd_id_seq', 5, true);


--
-- Name: projeto_proj_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.projeto_proj_cd_id_seq', 5, true);


--
-- Name: trabalha_em_trabem_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trabalha_em_trabem_cd_id_seq', 5, true);


--
-- Name: departamento departamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamento
    ADD CONSTRAINT departamento_pkey PRIMARY KEY (dep_cd_id);


--
-- Name: endereco endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (end_cd_id);


--
-- Name: funcionario funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (func_cd_id);


--
-- Name: projeto projeto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projeto
    ADD CONSTRAINT projeto_pkey PRIMARY KEY (proj_cd_id);


--
-- Name: trabalha_em trabalha_em_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trabalha_em
    ADD CONSTRAINT trabalha_em_pkey PRIMARY KEY (trabem_cd_id);


--
-- Name: departamento departamento_dep_fk_end_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamento
    ADD CONSTRAINT departamento_dep_fk_end_fkey FOREIGN KEY (dep_fk_end) REFERENCES public.endereco(end_cd_id);


--
-- Name: funcionario funcionario_func_fk_dep_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_func_fk_dep_fkey FOREIGN KEY (func_fk_dep) REFERENCES public.departamento(dep_cd_id);


--
-- Name: funcionario funcionario_func_fk_end_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_func_fk_end_fkey FOREIGN KEY (func_fk_end) REFERENCES public.endereco(end_cd_id);


--
-- Name: trabalha_em trabalha_em_trabem_fk_func_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trabalha_em
    ADD CONSTRAINT trabalha_em_trabem_fk_func_fkey FOREIGN KEY (trabem_fk_func) REFERENCES public.funcionario(func_cd_id);


--
-- Name: trabalha_em trabalha_em_trabem_fk_proj_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trabalha_em
    ADD CONSTRAINT trabalha_em_trabem_fk_proj_fkey FOREIGN KEY (trabem_fk_proj) REFERENCES public.projeto(proj_cd_id);


--
-- PostgreSQL database dump complete
--

